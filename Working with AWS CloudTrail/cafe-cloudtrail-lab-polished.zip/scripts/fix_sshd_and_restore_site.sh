#!/usr/bin/env bash
# Performs the in-lab changes to lock down sshd_config and restore the site image.
# MUST be run on the web server as root/ec2-user with sudo.
set -euo pipefail
# Backup current sshd_config
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak.$(date +%s)
# Replace PasswordAuthentication yes -> commented; ensure PasswordAuthentication no is present
sudo sed -i 's/^PasswordAuthentication yes/#&/' /etc/ssh/sshd_config || true
sudo sed -i 's/^#PasswordAuthentication no/PasswordAuthentication no/' /etc/ssh/sshd_config || true
sudo service sshd restart || true
echo "sshd_config updated and sshd restarted (if service present)."
# Restore website image if backup exists
if [ -f /var/www/html/cafe/images/Coffee-and-Pastries.backup ]; then
  sudo mv /var/www/html/cafe/images/Coffee-and-Pastries.backup /var/www/html/cafe/images/Coffee-and-Pastries.jpg
  echo "Website image restored."
else
  echo "No backup image found to restore in /var/www/html/cafe/images/"
fi