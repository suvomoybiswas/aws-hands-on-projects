#!/usr/bin/env bash
# Lookup CloudTrail events related to EC2 SecurityGroups for the Cafe Web Server instance.
set -euo pipefail
region=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep region | cut -d '"' -f4)
sgId=$(aws ec2 describe-instances --filters "Name=tag:Name,Values='Cafe Web Server'" --query 'Reservations[*].Instances[*].SecurityGroups[*].[GroupId]' --region $region --output text)
echo "Region: $region"
echo "SecurityGroupID: $sgId"
aws cloudtrail lookup-events --lookup-attributes AttributeKey=ResourceType,AttributeValue=AWS::EC2::SecurityGroup --region $region --output text | grep "$sgId" || true