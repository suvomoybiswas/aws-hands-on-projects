#!/usr/bin/env bash
# Helper: create CloudTrail trail named 'monitor' and an S3 bucket monitoring####
# WARNING: Intended for lab environments. Review before running.

set -euo pipefail
if [ -z "${1-}" ]; then
  echo "Usage: $0 <monitoring-bucket-name> [kms-alias]"
  exit 1
fi
BUCKET="$1"
KMS_ALIAS="${2:-}"

# create S3 bucket (region assumed from AWS CLI config)
aws s3api create-bucket --bucket "$BUCKET" --create-bucket-configuration LocationConstraint=$(aws configure get region || echo us-east-1)

# create trail
if [ -n "$KMS_ALIAS" ]; then
  aws cloudtrail create-trail --name monitor --s3-bucket-name "$BUCKET" --kms-key-id "alias/$KMS_ALIAS"
else
  aws cloudtrail create-trail --name monitor --s3-bucket-name "$BUCKET"
fi

aws cloudtrail start-logging --name monitor
echo "Trail 'monitor' created and logging started to s3://$BUCKET/"