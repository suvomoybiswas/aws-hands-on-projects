#!/usr/bin/env bash
# Fetch CloudTrail logs from the monitoring S3 bucket and extract them locally.
set -euo pipefail
if [ -z "${1-}" ]; then
  echo "Usage: $0 <monitoring-bucket-name>"
  exit 1
fi
BUCKET="$1"
mkdir -p ctraillogs
cd ctraillogs
aws s3 cp "s3://$BUCKET/" . --recursive
gunzip -f *.gz || true
echo "Downloaded and extracted logs into $(pwd)"