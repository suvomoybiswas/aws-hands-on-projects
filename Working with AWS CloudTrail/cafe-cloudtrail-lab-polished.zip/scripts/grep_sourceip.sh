#!/usr/bin/env bash
# Example: grep sourceIPAddress from all local CloudTrail json files
if [ -z "${1-}" ]; then
  echo "Usage: $0 <WebServerIP>"
  exit 1
fi
ip="$1"
for i in $(ls *.json 2>/dev/null); do
  echo "---- $i ----"
  cat "$i" | python -m json.tool | grep sourceIPAddress || true
done