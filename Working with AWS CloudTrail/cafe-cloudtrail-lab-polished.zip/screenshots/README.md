Add your lab screenshots here before uploading to GitHub. Example filenames:

- 01_website_before.png
- 02_added_ssh_my_ip.png
- 03_cloudtrail_created.png
- 04_website_defaced.png
- 05_sg_rule_0.0.0.0-0.png
- 06_grep_results.png
- 07_athena_query.png
- 08_who_chaos_user.png
- 09_sshd_config.png
- 10_restored_website.png
