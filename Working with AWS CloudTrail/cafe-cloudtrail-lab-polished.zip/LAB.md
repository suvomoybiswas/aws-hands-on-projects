# Café CloudTrail Lab — Polished Instructions

## Purpose
Recreate and document the educational lab that demonstrates how AWS CloudTrail can be used to investigate a compromised EC2 web server (the "Café Web Server"). The lab guides you through creating a CloudTrail trail, collecting logs, searching logs with `grep` and the AWS CLI, importing logs into Athena, identifying the IAM user who created a malicious security group rule, removing that user, and cleaning the EC2 instance.

## Project layout
- `scripts/` — helper shell scripts
- `athena/` — Athena CREATE TABLE + example queries
- `screenshots/` — **empty**. Add your screenshots here before uploading.
- `LAB.md` — this polished step-by-step guide
- `README.md`, `LICENSE`, `.gitignore`

## Quick checklist (what you will do in the lab)
1. Inspect the Café website.
2. Create a CloudTrail trail called `monitor` that writes to an S3 bucket `monitoring####`.
3. Observe the Café website being defaced (lab behavior).
4. SSH into the Café Web Server instance as `ec2-user`.
5. Download CloudTrail logs from the `monitoring####` bucket.
6. Uncompress and inspect the JSON logs with `python -m json.tool` and `grep`.
7. Use `aws cloudtrail lookup-events` to narrow down events acting on the EC2 security group.
8. Create an Athena table for the CloudTrail logs and run SQL queries to find the offending IAM user and details.
9. On the EC2 instance: remove OS `chaos-user`, lock down SSH (`/etc/ssh/sshd_config`), and restore the website image.
10. In IAM: delete the `chaos` user.

## Detailed steps (polished)

> **Preconditions**
> - You have lab credentials and the lab AWS Console opened (the original lab auto-logs you in).
> - You have a running EC2 instance tagged `Cafe Web Server`.
> - The lab instructions assume you run commands either on the EC2 instance (via SSH) or from your workstation with `aws` CLI configured.

### 1 — Modify the Web Server security group and verify website
1. Open EC2 Console → Instances → select `Cafe Web Server`.
2. Copy the Public IPv4 address; open `http://<WebServerIP>/cafe/` and verify the site is normal.
3. In EC2 → Security Groups, edit inbound rules for the web server's group and add a rule:
   - Type: SSH, Port: 22, Source: **My IP** (CIDR `/32`).

### 2 — Create a CloudTrail trail
1. Console → CloudTrail → Trails → Create trail.
2. Name = `monitor`
3. Create a new S3 bucket named `monitoring####` (lab auto-generates ####)
4. AWS KMS alias = `<your_initials>-KMS` (optional in lab)
5. Complete the wizard and confirm the trail is visible.
6. Wait ~1–5 minutes for logs to be delivered.

### 3 — Observe the hack and identify the changed security group
1. Refresh `http://<WebServerIP>/cafe/` (shift-refresh to avoid cache).
2. If defaced, inspect the `Cafe Web Server` instance → Security → Inbound rules.
3. Note: a new inbound SSH rule `0.0.0.0/0` will appear (the lab attacker added it).

### 4 — SSH into the instance and collect CloudTrail logs (on the instance)
1. SSH as `ec2-user` using the lab key pair.
2. On the instance:
   ```
   mkdir -p ~/ctraillogs
   cd ~/ctraillogs
   aws s3 ls
   aws s3 cp s3://monitoring####/ . --recursive
   gunzip *.gz
   ```
3. Inspect a file:
   ```
   cat filename.json | python -m json.tool
   ```

### 5 — Grep & CLI analysis (examples)
- Set environment variables:
  ```
  ip=<WebServerIP>
  region=$(curl http://169.254.169.254/latest/dynamic/instance-identity/document | grep region | cut -d '"' -f4)
  ```
- Extract lines containing `sourceIPAddress` across files:
  ```
  for i in $(ls); do echo $i && cat $i | python -m json.tool | grep sourceIPAddress ; done
  ```
- Use AWS CLI CloudTrail lookup (from instance or workstation):
  ```
  aws cloudtrail lookup-events --lookup-attributes AttributeKey=ResourceType,AttributeValue=AWS::EC2::SecurityGroup --region $region --output text
  ```
- Narrow to the specific security group:
  ```
  sgId=$(aws ec2 describe-instances --filters "Name=tag:Name,Values='Cafe Web Server'" --query 'Reservations[*].Instances[*].SecurityGroups[*].[GroupId]' --region $region --output text)
  aws cloudtrail lookup-events --lookup-attributes AttributeKey=ResourceType,AttributeValue=AWS::EC2::SecurityGroup --region $region --output text | grep $sgId
  ```

### 6 — Athena analysis
1. In CloudTrail Console → Event history → Create Athena table → point to `s3://monitoring####/`.
2. In Athena, set query results location to `s3://monitoring####/results/`.
3. Example queries:
   ```sql
   SELECT useridentity.userName, eventtime, eventsource, eventname, requestparameters
   FROM cloudtrail_logs_monitoring####
   LIMIT 30;
   ```
   And for recent actors:
   ```sql
   SELECT DISTINCT useridentity.userName, eventName, eventSource
   FROM cloudtrail_logs_monitoring####
   WHERE from_iso8601_timestamp(eventtime) > date_add('day', -1, now())
   ORDER BY eventSource;
   ```
4. Use WHERE clauses to filter `eventsource = 'ec2.amazonaws.com'` and `eventname LIKE '%AuthorizeSecurityGroup%'` or `eventname LIKE '%AuthorizeSecurityGroupIngress%'`.

### 7 — Clean up the instance (OS-level)
1. On the instance, check recent auth:
   ```
   sudo aureport --auth
   who
   ```
2. If `chaos-user` exists and is logged in:
   ```
   sudo userdel -r chaos-user   # will fail if logged in
   sudo kill -9 <ProcNum>       # kill their session
   sudo userdel -r chaos-user
   ```
3. Lock down SSH:
   ```
   sudo vi /etc/ssh/sshd_config
   # ensure PasswordAuthentication no is set (comment out yes)
   sudo service sshd restart
   ```
4. Remove malicious inbound rule in EC2 Security Group (console).

### 8 — Restore website files
```
cd /var/www/html/cafe/images/
ls -l
sudo mv Coffee-and-Pastries.backup Coffee-and-Pastries.jpg
```

### 9 — Remove the IAM user
1. Console → IAM → Users → select `chaos` → Delete.

## What to include before uploading to GitHub
- Add screenshots of key steps and results into the `screenshots/` folder. Example files:
  - `01_website_before.png`
  - `02_added_ssh_my_ip.png`
  - `03_cloudtrail_created.png`
  - `04_website_defaced.png`
  - `05_sg_rule_0.0.0.0-0.png`
  - `06_grep_results.png`
  - `07_athena_query.png`
  - `08_who_chaos_user.png`
  - `09_sshd_config.png`
  - `10_restored_website.png`
- Commit and push to GitHub.

## Security & ethical note
This repository documents an educational lab. The steps and scripts are intended for **laboratory** or **sandbox** environments where you have explicit permission to test. Do **not** run investigative or remediation commands against production accounts without proper authorization.