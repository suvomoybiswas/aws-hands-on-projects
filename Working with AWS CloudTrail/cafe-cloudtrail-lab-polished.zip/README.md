# Café CloudTrail Forensics — Polished Lab Project

This repository packages the *Café CloudTrail* lab into a polished, ready-to-upload GitHub project.

**What's included**
- Step-by-step lab instructions (`LAB.md`) rewritten and cleaned for reuse.
- Helpful automation and analysis scripts (`scripts/`) to speed up tasks described in the lab.
- Athena `CREATE TABLE` + example queries (`athena/`).
- `LICENSE` (MIT) and `.gitignore`.
- An empty `screenshots/` folder — **your only remaining task** is to add the screenshots you took during the lab to that folder before uploading to GitHub.

**How to use**
1. Download and unzip the project.
2. Add your screenshots into the `screenshots/` folder.
3. Inspect and, if desired, run the helper scripts from a machine configured with AWS CLI credentials and permissions for the lab account.
4. Push to a new GitHub repository and upload.

> NOTE: The included scripts are helpers intended for educational lab environments. Do **not** run them against production accounts without reviewing and understanding them first.