-- Athena: CloudTrail CREATE EXTERNAL TABLE example (adjust LOCATION to your bucket)
CREATE EXTERNAL TABLE IF NOT EXISTS cloudtrail_logs_monitoringXXXX (
  eventversion string,
  useridentity struct<
    type:string,principalId:string,arn:string,accountId:string,accessKeyId:string,userName:string>,
  eventtime string,
  eventsource string,
  eventname string,
  awsRegion string,
  sourceIPAddress string,
  userAgent string,
  requestParameters string,
  responseElements string,
  additionalEventData string,
  eventID string,
  eventType string,
  apiVersion string
)
PARTITIONED BY (dt string)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
LOCATION 's3://monitoringXXXX/AWSLogs/your-account-id/CloudTrail/'
TBLPROPERTIES ('projection.enabled'='false');