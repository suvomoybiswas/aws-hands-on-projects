# AWS Auto Scaling and Load Balancing Lab

## Overview
This project demonstrates how to set up a scalable and load-balanced web application infrastructure using **Amazon EC2 Auto Scaling** and **Elastic Load Balancer (ELB)**.  
The lab follows a step-by-step process to create an AMI, launch templates, load balancers, and an Auto Scaling group configured with CloudWatch alarms for automatic scaling.

---

## Architecture

### Starting Architecture
Single EC2 web server running in a public subnet.

### Final Architecture
- Application Load Balancer (ALB) distributing traffic across EC2 instances
- EC2 instances launched automatically by an Auto Scaling group
- Instances deployed across **two Availability Zones**
- **Private subnets** used for EC2 instances
- **Public subnets** used for the ALB

---

## AWS Services Used
- **Amazon EC2**
- **Amazon Machine Image (AMI)**
- **Elastic Load Balancing (ALB)**
- **EC2 Auto Scaling**
- **Amazon CloudWatch**
- **VPC, Subnets, Security Groups**

---

## Lab Tasks

### 1. Creating an AMI for Auto Scaling
Created an AMI named `Web Server AMI` from an existing EC2 instance (`Web Server 1`) to standardize new instance configurations.

### 2. Creating a Load Balancer
Created an **Application Load Balancer** named `LabELB` with target group `lab-target-group` for HTTP traffic across multiple AZs.

### 3. Creating a Launch Template
Created a launch template named `lab-app-launch-template` using the AMI and configured `t3.micro` instances with `Web Security Group`.

### 4. Creating an Auto Scaling Group
Created an Auto Scaling Group named `Lab Auto Scaling Group` with:
- Desired capacity: 2
- Minimum: 2
- Maximum: 4  
Attached it to the load balancer target group and configured ELB health checks.

### 5. Verifying Load Balancing
Confirmed that both launched EC2 instances were healthy and that the Load Balancer distributed traffic evenly.

### 6. Testing Auto Scaling
Triggered CPU load through the Load Test application. CloudWatch alarms automatically launched additional instances when CPU > 50% for 3 minutes.

### 7. Terminating Web Server 1
Terminated the initial `Web Server 1` instance as the Auto Scaling group now manages instance creation.

---

## Optional Challenge – AWS CLI
Example AWS CLI command to create an AMI:
```bash
aws ec2 create-image   --instance-id i-xxxxxxxxxxxxxxxxx   --name "Web-Server-AMI-CLI"   --description "AMI created via AWS CLI for Auto Scaling Lab"   --no-reboot
```

---

## Results
✅ Successfully implemented a fault-tolerant, auto-scaling web application.  
✅ Verified automated scaling with CloudWatch alarms.  
✅ Achieved cost-efficiency through dynamic instance management.

---

## Next Steps
- Add screenshots in the `/screenshots` directory.
- Deploy similar setup with Terraform or AWS CDK for IaC (Infrastructure as Code).
- Monitor scaling events and resource utilization through CloudWatch dashboards.

---

## Author
**Suvo Biswas**  
Location: Jamaica, New York  
Project Type: AWS Lab – Auto Scaling and Load Balancing  
Duration: ~45 minutes
