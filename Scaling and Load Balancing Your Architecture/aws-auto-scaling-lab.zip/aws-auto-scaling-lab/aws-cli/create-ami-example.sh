#!/bin/bash
# Example AWS CLI script to create an AMI from an EC2 instance

INSTANCE_ID="i-xxxxxxxxxxxxxxxxx"   # Replace with your instance ID
AMI_NAME="Web-Server-AMI-CLI"

aws ec2 create-image   --instance-id $INSTANCE_ID   --name "$AMI_NAME"   --description "AMI created via AWS CLI for Auto Scaling Lab"   --no-reboot
