# AWS Auto Scaling and Load Balancing – Detailed Lab Report

## Objective
To implement a fault-tolerant and scalable architecture using AWS Elastic Load Balancing (ELB) and EC2 Auto Scaling. This setup ensures high availability and performance under variable workloads.

---

## Steps Summary

### Step 1: Create an AMI
Created an Amazon Machine Image (AMI) named *Web Server AMI* from the running EC2 instance (*Web Server 1*).

### Step 2: Create an Application Load Balancer
Configured a load balancer named *LabELB* within *Lab VPC*, mapped across two Availability Zones using public subnets, and associated it with *Web Security Group* for HTTP access.

### Step 3: Create a Launch Template
Created a launch template *lab-app-launch-template* based on the AMI and configured the instance type `t3.micro` with the *Web Security Group*.

### Step 4: Create an Auto Scaling Group
Used the launch template to create an Auto Scaling group named *Lab Auto Scaling Group*.
- Minimum size: 2  
- Maximum size: 4  
- Desired capacity: 2  
Attached it to *lab-target-group* and configured health checks to use ELB.

### Step 5: Verify Load Balancing
Two new instances named *Lab Instance* were launched and registered as healthy targets with the ALB. Accessed the application successfully via the ALB DNS name.

### Step 6: Test Auto Scaling
Generated artificial load using the Load Test app, which triggered the *AlarmHigh* CloudWatch alarm, causing Auto Scaling to launch additional EC2 instances.

### Step 7: Terminate Web Server 1
Terminated the original EC2 instance (*Web Server 1*), as its role was complete.

---

## AWS CLI Challenge (Optional)
Created an AMI using the AWS CLI:
```bash
aws ec2 create-image --instance-id i-xxxxxxxx --name "WebServerAMI_CLI" --description "CLI-created AMI" --no-reboot
```

---

## Observations
- ELB effectively distributed traffic between multiple EC2 instances.
- Auto Scaling dynamically maintained CPU utilization near the defined threshold.
- The architecture successfully provided both **scalability** and **fault tolerance**.

---

## Conclusion
This lab demonstrates how AWS Auto Scaling and Elastic Load Balancing can be combined to build highly available and self-healing infrastructures. These mechanisms ensure optimal performance while reducing costs during low usage periods.
