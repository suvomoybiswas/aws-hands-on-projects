#!/bin/bash
# Script to update the Café & Bakery static website on S3
aws s3 cp /home/ec2-user/sysops-activity-files/static-website/ s3://biswas234/ --recursive --acl public-read
