# AWS S3 Static Website Deployment (Café & Bakery Project)

This project demonstrates how to host a static website on **Amazon S3** using the **AWS Command Line Interface (AWS CLI)**, based on the AWS hands-on lab: *Creating a Website on S3*.

---

## 🧭 Overview

You will:
- Create an S3 bucket and configure it for static website hosting  
- Create an IAM user with S3 full access  
- Upload a simple Café & Bakery website to S3  
- Create an update script (`update-website.sh`) to automate future uploads  

---

## ⚙️ Prerequisites

- AWS account (temporary lab or personal)
- AWS CLI installed and configured (`aws configure`)
- EC2 instance or local terminal access

---

## 🪜 Step-by-Step Instructions

### **Task 1: Connect to EC2 using SSM**
1. In the AWS Console, open **Systems Manager > Session Manager**.
2. Connect to the provided EC2 instance.  
3. In the session, switch user:
   ```bash
   sudo su -l ec2-user
   pwd
   ```

### **Task 2: Configure AWS CLI**
```bash
aws configure
```
Provide:
```
AWS Access Key ID: <your-key>
AWS Secret Access Key: <your-secret>
Default region name: us-west-2
Default output format: json
```

### **Task 3: Create an S3 Bucket**
Use a unique bucket name (your bucket is already set as `biswas234`):
```bash
aws s3api create-bucket --bucket biswas234 --region us-west-2 --create-bucket-configuration LocationConstraint=us-west-2
```

### **Task 4: Create an IAM User**
```bash
aws iam create-user --user-name awsS3user
aws iam create-login-profile --user-name awsS3user --password Training123!
```
Attach the S3 Full Access policy:
```bash
aws iam attach-user-policy --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess --user-name awsS3user
```

### **Task 5: Adjust Bucket Permissions**
- In the S3 Console → **Permissions** tab  
  - Disable “Block all public access”  
  - Enable “ACLs” (Object Ownership → ACLs enabled)  

### **Task 6: Extract Static Website Files**
```bash
cd ~/sysops-activity-files
tar xvzf static-website-v2.tar.gz
cd static-website
ls
```

### **Task 7: Upload Files to S3**
Configure the bucket for static website hosting:
```bash
aws s3 website s3://biswas234/ --index-document index.html
```

Upload files:
```bash
aws s3 cp /home/ec2-user/sysops-activity-files/static-website/ s3://biswas234/ --recursive --acl public-read
```

Verify upload:
```bash
aws s3 ls biswas234
```

View your website:  
👉 [http://biswas234.s3-website-us-west-2.amazonaws.com](http://biswas234.s3-website-us-west-2.amazonaws.com)

### **Task 8: Create Update Script**
File: `update-website.sh`
```bash
#!/bin/bash
aws s3 cp /home/ec2-user/sysops-activity-files/static-website/ s3://biswas234/ --recursive --acl public-read
```
Make it executable:
```bash
chmod +x update-website.sh
```

To update your site after editing local files:
```bash
./update-website.sh
```

---

## 🧰 Project Structure

```
aws-s3-static-website/
│
├── README.md
├── update-website.sh
│
└── static-website/
    ├── index.html
    ├── css/
    │   └── style.css
    └── images/
```

---

## 🌐 Website Endpoint

**URL:** [http://biswas234.s3-website-us-west-2.amazonaws.com](http://biswas234.s3-website-us-west-2.amazonaws.com)

This site is hosted directly on Amazon S3 as a static website.

---

## ✅ Conclusion

You successfully:
- Configured AWS CLI  
- Created an S3 bucket and IAM user  
- Uploaded a static site to S3  
- Automated deployment with a bash script

You can now use this project as a GitHub reference or personal AWS deployment guide.
