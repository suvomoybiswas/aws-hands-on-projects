# Amazon EBS Lab — Hands-On Demonstration

**Author:** Suvo Biswas  
**Date:** November 2025  

---

## 🌐 Overview
This repository documents a hands-on lab with **Amazon Elastic Block Store (Amazon EBS)** — a high-performance, durable block storage service for Amazon EC2.

In this project, I performed key operations on EBS volumes, including:
- Creating a new EBS volume  
- Attaching and mounting it to an EC2 instance  
- Creating a snapshot for backup  
- Restoring a new EBS volume from that snapshot  

---

## 🧭 Architecture Diagram
![Architecture Diagram](screenshots/architecture-diagram.png)

---

## 🧩 Step-by-Step Walkthrough

### 1️⃣ Checking the EC2 Lab Instance
![01 - Lab instance](screenshots/01-lab-instance.png)

### 2️⃣ Creating a New EBS Volume
![02 - Create volume](screenshots/02-create-volume.png)

### 3️⃣ Attaching the EBS Volume
![03 - Attach volume](screenshots/03-attach-volume.png)

### 4️⃣ Creating and Mounting the Filesystem
![04 - mkfs and mount](screenshots/04-mkfs-mount.png)

### 5️⃣ Writing Data to the Volume
![05 - file created](screenshots/05-file-created.png)

### 6️⃣ Creating a Snapshot
![06 - create snapshot](screenshots/06-create-snapshot.png)

### 7️⃣ Restoring from the Snapshot
![07 - restored volume](screenshots/07-restored-volume.png)

---

## 📁 Repository Contents
| File/Folder | Description |
|--------------|-------------|
| `screenshots/` | All lab screenshots and architecture diagram |
| `scripts/mount-commands.sh` | Bash script to format and mount EBS volume |
| `README.md` | Full documentation and walkthrough |

---

## 💻 Script Usage
```bash
chmod +x scripts/mount-commands.sh
./scripts/mount-commands.sh
```

---

## ⚙️ Security Note
> Do not include AWS credentials or PEM files in your repository.  
> This project uses safe, simulated lab data only.

---

## 👨‍💻 Created by
**Suvo Biswas**  
🌐 [GitHub](https://github.com/) | 📘 AWS Hands-On Lab Project
