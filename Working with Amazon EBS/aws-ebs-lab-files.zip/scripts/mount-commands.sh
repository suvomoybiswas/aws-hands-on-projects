#!/bin/bash
# mount-commands.sh - Automates EBS volume mounting steps
set -euo pipefail

echo "Formatting the EBS volume (/dev/sdb)..."
sudo mkfs -t ext3 /dev/sdb

echo "Creating mount directory..."
sudo mkdir -p /mnt/data-store

echo "Mounting volume..."
sudo mount /dev/sdb /mnt/data-store

echo "Persisting mount in /etc/fstab..."
echo "/dev/sdb   /mnt/data-store ext3 defaults,noatime 1 2" | sudo tee -a /etc/fstab

echo "Verifying mount..."
df -h | grep data-store

echo "✅ EBS volume mounted successfully."
