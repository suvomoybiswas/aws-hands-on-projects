#!/bin/bash
nmap <WebServerIP>