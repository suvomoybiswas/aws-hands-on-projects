#!/bin/bash
aws configure
aws ec2 describe-vpcs