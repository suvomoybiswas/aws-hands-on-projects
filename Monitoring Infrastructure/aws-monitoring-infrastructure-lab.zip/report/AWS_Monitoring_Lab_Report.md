# AWS Monitoring Infrastructure Lab Report
**Author:** Suvo Biswas  
**Location:** Jamaica, New York  
**Completion Date:** 2025  

---

## Task 1: Installing the CloudWatch Agent
Used **AWS Systems Manager Run Command** to install the `AmazonCloudWatchAgent` package on the Web Server instance.  
Then created a configuration in **AWS Systems Manager Parameter Store** named `Monitor-Web-Server` to collect application logs and system metrics.  
Finally, configured the agent using the `AmazonCloudWatch-ManageAgent` document.

---

## Task 2: Monitoring Application Logs using CloudWatch Logs
Verified log files (`HttpAccessLog` and `HttpErrorLog`) were successfully sent to **CloudWatch Logs**.  
Generated 404 errors to populate logs and confirmed log entries in CloudWatch.

---

## Task 3: Create a Metric Filter in CloudWatch Logs
Defined a filter pattern:  
```
[ip, id, user, timestamp, request, status_code=404, size]
```
This filter extracts 404 errors and creates a **custom metric** under the namespace `LogMetrics`.

---

## Task 4: Create an Alarm Using the Filter
Created a CloudWatch Alarm named **404 Errors** to trigger when 5 or more 404s occur within one minute.  
Configured SNS topic for email notification and confirmed the alarm by generating multiple 404 requests.

---

## Task 5: Monitoring Instance Metrics Using CloudWatch
Viewed EC2 instance performance metrics (CPU, disk, network) under **EC2 → Monitoring**.  
Then accessed **CloudWatch Metrics → CWAgent** to view detailed system-level data (memory, disk usage, I/O).

---

## Task 6: Creating Real-Time Notifications
Set up a **CloudWatch Event Rule** to trigger whenever an instance enters the `stopped` or `terminated` state.  
The event sends notifications via the existing SNS topic configured earlier.

---

## Task 7: Configure a Real-Time Notification
Verified the SNS topic subscription email.  
Stopped the instance and received a JSON-formatted email notification confirming the state change.

---

## Task 8: Monitoring for Infrastructure Compliance
Enabled **AWS Config** and added managed rules:
1. `required-tags` – checks if resources have the `project` tag.
2. `ec2-volume-inuse-check` – checks for unattached EBS volumes.  

Verified compliance results showing both compliant and non-compliant resources.

---

## Summary
This lab demonstrated end-to-end infrastructure monitoring on AWS using CloudWatch and AWS Config.  
The setup enables proactive alerting, visibility into logs and metrics, and continuous compliance validation.

