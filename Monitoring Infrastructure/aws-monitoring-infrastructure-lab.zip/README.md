# AWS Monitoring Infrastructure Project

This project demonstrates how to monitor AWS infrastructure and applications using **Amazon CloudWatch**, **AWS Systems Manager**, and **AWS Config**.

## 🧩 Overview
This lab was completed to gain hands-on experience in:
- Installing and configuring the **CloudWatch Agent**
- Monitoring **application logs** and **system metrics**
- Creating **metric filters** and **alarms**
- Setting up **real-time notifications**
- Enforcing **infrastructure compliance** with **AWS Config**

---

## 🧠 Objectives
After completing this project, you can:
1. Install the CloudWatch Agent on EC2 instances using Systems Manager.
2. Monitor logs via CloudWatch Logs.
3. Create alarms for 404 errors.
4. View CloudWatch Metrics for EC2 performance.
5. Set up CloudWatch Events for instance state changes.
6. Use AWS Config to check resource compliance.

---

## 🏗️ Steps Performed

| Task | Description |
|------|--------------|
| **1** | Installed the CloudWatch Agent using AWS Systems Manager |
| **2** | Monitored application logs using CloudWatch Logs |
| **3** | Created a metric filter in CloudWatch Logs |
| **4** | Created an alarm to alert on 404 errors |
| **5** | Monitored instance metrics using CloudWatch Metrics |
| **6** | Created real-time notifications using CloudWatch Events |
| **7** | Configured notifications via SNS |
| **8** | Monitored compliance using AWS Config |

---

## 📸 Screenshots
Add your screenshots to the `/screenshots` folder. Suggested filenames:
- 01_installing_cloudwatch_agent.png
- 02_monitoring_logs.png
- 03_create_metric_filter.png
- 04_create_alarm.png
- 05_monitoring_metrics.png
- 06_creating_notifications.png
- 07_configure_realtime_notification.png
- 08_monitoring_compliance.png

---

## 🧰 Technologies Used
- **Amazon EC2**
- **Amazon CloudWatch (Metrics, Logs, Events)**
- **AWS Systems Manager**
- **Amazon SNS**
- **AWS Config**

---

## 👤 Author
**Suvo Biswas**  
📍 Jamaica, New York  
🗓️ Completed: 2025  

