# AWS Tagging Lab

This project accompanies the **"Managing Resources with Tagging"** AWS Academy lab.

## Objectives
- Understand how to use tags to organize AWS resources.
- Use EC2 instance tags to manage environments (e.g., Production, Development).
- Automate tagging and instance management with shell and PHP scripts.

## Structure
- `LAB.md` – Full step-by-step lab guide.
- `scripts/` – Shell scripts used in the lab.
- `aws-tools/` – PHP SDK script example (`stopinator.php`).
- `screenshots/` – Add your screenshots here before publishing.
- `.gitignore`, `LICENSE` – Basic project housekeeping.

## Notes
This project is intended for **educational purposes only** and should be run only in sandbox environments.
