# Managing Resources with Tagging — AWS Lab Guide

This lab demonstrates how to use **AWS tags** to manage EC2 resources in different environments.

## Objectives
- View and interpret resource tags.
- Modify tags via the AWS CLI.
- Use AWS SDK (PHP) to automate EC2 management based on tags.

---

### Part 1: Analyze Resources

1. Connect to the AWS Management Console.
2. Open **EC2 Dashboard → Instances**.
3. Review the **Project** and **Environment** tags for each instance.

---

### Part 2: Modify Resource Tags with AWS CLI

1. Connect to the **Command Host** instance via Systems Manager Session Manager or SSH.
2. Create and run a Bash script named `change-resource-tags.sh`:

```bash
#!/bin/bash
echo "Finding ERPSystem development instances..."
instances=$(aws ec2 describe-instances   --filters "Name=tag:Project,Values=ERPSystem" "Name=tag:Environment,Values=Development"   --query "Reservations[*].Instances[*].InstanceId" --output text)

echo "Updating Version tag to 1.1..."
for id in $instances; do
  aws ec2 create-tags --resources $id --tags Key=Version,Value=1.1
  echo "Updated $id"
done
```

3. Make it executable and run it:
```bash
chmod +x change-resource-tags.sh
./change-resource-tags.sh
```

4. Verify the tags in the EC2 Console.

---

### Part 3: Automate Instance Management with AWS SDK (PHP)

1. Navigate to the **aws-tools** directory on the Command Host.
2. Open `stopinator.php` and review the script:

```php
<?php
require 'vendor/autoload.php';

use Aws\Ec2\Ec2Client;

$ec2 = new Ec2Client([
    'version' => 'latest',
    'region'  => 'us-east-1'
]);

$instances = $ec2->describeInstances([
    'Filters' => [
        ['Name' => 'tag:Environment', 'Values' => ['Development']],
        ['Name' => 'instance-state-name', 'Values' => ['running']]
    ]
]);

$instanceIds = [];
foreach ($instances['Reservations'] as $res) {
    foreach ($res['Instances'] as $inst) {
        $instanceIds[] = $inst['InstanceId'];
    }
}

if (!empty($instanceIds)) {
    echo "Stopping instances: " . implode(', ', $instanceIds) . "\n";
    $ec2->stopInstances(['InstanceIds' => $instanceIds]);
} else {
    echo "No running development instances found.\n";
}
?>
```

3. Run the script:
```bash
php stopinator.php
```

4. Check that development instances are stopped in the EC2 Console.

---

### Part 4: Screenshot Checklist

Add these screenshots to `/screenshots/` before submitting:
1. `01_connect_command_host.png`
2. `02_find_instances_project.png`
3. `03_change_version_tag.png`
4. `04_examine_stopinator_script.png`
5. `05_stop_restart_development_instances.png`
