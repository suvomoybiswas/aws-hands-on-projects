# Screenshots Placeholder

Add the following screenshots before submitting your lab report or uploading to GitHub:

1. 01_connect_command_host.png
2. 02_find_instances_project.png
3. 03_change_version_tag.png
4. 04_examine_stopinator_script.png
5. 05_stop_restart_development_instances.png
