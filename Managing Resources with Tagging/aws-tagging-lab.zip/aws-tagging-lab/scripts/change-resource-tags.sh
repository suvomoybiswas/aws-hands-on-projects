#!/bin/bash
# change-resource-tags.sh
# Updates the Version tag for ERPSystem development instances

echo "Finding ERPSystem development instances..."
instances=$(aws ec2 describe-instances   --filters "Name=tag:Project,Values=ERPSystem" "Name=tag:Environment,Values=Development"   --query "Reservations[*].Instances[*].InstanceId" --output text)

echo "Updating Version tag to 1.1..."
for id in $instances; do
  aws ec2 create-tags --resources $id --tags Key=Version,Value=1.1
  echo "Updated $id"
done
