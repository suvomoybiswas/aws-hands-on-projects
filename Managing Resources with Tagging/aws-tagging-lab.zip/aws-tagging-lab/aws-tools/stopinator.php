<?php
// stopinator.php
// Example AWS SDK for PHP script to stop EC2 instances by tag

require 'vendor/autoload.php';

use Aws\Ec2\Ec2Client;

$ec2 = new Ec2Client([
    'version' => 'latest',
    'region'  => 'us-east-1'
]);

$instances = $ec2->describeInstances([
    'Filters' => [
        ['Name' => 'tag:Environment', 'Values' => ['Development']],
        ['Name' => 'instance-state-name', 'Values' => ['running']]
    ]
]);

$instanceIds = [];
foreach ($instances['Reservations'] as $res) {
    foreach ($res['Instances'] as $inst) {
        $instanceIds[] = $inst['InstanceId'];
    }
}

if (!empty($instanceIds)) {
    echo "Stopping instances: " . implode(', ', $instanceIds) . "\n";
    $ec2->stopInstances(['InstanceIds' => $instanceIds]);
} else {
    echo "No running development instances found.\n";
}
?>