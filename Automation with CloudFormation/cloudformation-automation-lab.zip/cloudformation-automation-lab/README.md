# Lab — Automation with CloudFormation

This repository contains a GitHub-ready lab for **Automation with AWS CloudFormation**. It guides you through deploying a stack that creates a VPC and Security Group, updating the stack to add an S3 bucket, then adding an EC2 instance, and finally deleting the stack.

## Lab overview

- **Duration:** ~45 minutes
- **Objectives:**
  - Deploy a CloudFormation stack that creates a VPC and Security Group.
  - Update the stack to add an S3 bucket.
  - Update the stack to add an EC2 instance using an SSM parameter for the AMI.
  - Delete the stack and confirm resources are removed.
- **Prerequisites:** AWS account with sufficient permissions (CloudFormation, EC2, S3, IAM), AWS CLI configured, and an EC2 KeyPair for SSH if you want to connect to the instance.

## Repository structure

```
cloudformation-automation-lab/
├── README.md
├── templates/
│   ├── task1.yaml        # VPC + Security Group
│   ├── task2.yaml        # task1 + S3 Bucket
│   └── task3.yaml        # task2 + EC2 Instance + parameter for AMI
├── scripts/
│   ├── create-stack.sh
│   ├── update-stack.sh
│   ├── describe-stack.sh
│   ├── delete-stack.sh
│   └── validate-template.sh
├── docs/
│   ├── TASK1_Deploy_Stack.md
│   ├── TASK2_Add_S3_Bucket.md
│   ├── TASK3_Add_EC2_Instance.md
│   └── TASK4_Delete_Stack.md
└── screenshots/
    └── README.md
```

## Quick usage examples

Validate a template before using it:
```bash
./scripts/validate-template.sh templates/task1.yaml
```

Create the initial stack (task1.yaml):
```bash
./scripts/create-stack.sh task1 templates/task1.yaml <KeyName>
```

Update the stack with a new template:
```bash
./scripts/update-stack.sh templates/task2.yaml
```

Monitor resources (press Ctrl-C to stop):
```bash
./scripts/describe-stack.sh
```

Delete the stack:
```bash
./scripts/delete-stack.sh
```

For detailed step-by-step instructions, see the files in `docs/`.

---
