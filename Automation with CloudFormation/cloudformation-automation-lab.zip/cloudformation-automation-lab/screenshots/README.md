# Screenshots

This folder contains placeholder filenames for screenshots you can add to the repository before publishing to GitHub.

Suggested names:
- step1-create-stack.png
- step2-add-s3.png
- step3-add-ec2.png
- step4-delete-stack.png
