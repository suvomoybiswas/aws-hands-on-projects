#!/bin/bash
# Delete stack 'Lab'
set -euo pipefail
STACKNAME="Lab"
aws cloudformation delete-stack --stack-name ${STACKNAME}
echo "Delete requested for stack ${STACKNAME}. Use describe-stack-resources to monitor."
