#!/bin/bash
# Usage: ./update-stack.sh <template-file> [KeyName]
set -euo pipefail
if [ $# -lt 1 ]; then
  echo "Usage: $0 <template-file> [KeyName]"
  exit 1
fi
TEMPLATE="$1"
STACKNAME="Lab"
shift 1
if [ $# -ge 1 ]; then
  KEYNAME="$1"
  aws cloudformation update-stack --stack-name ${STACKNAME} --template-body file://${TEMPLATE} --parameters ParameterKey=KeyName,ParameterValue=${KEYNAME} --capabilities CAPABILITY_NAMED_IAM
else
  aws cloudformation update-stack --stack-name ${STACKNAME} --template-body file://${TEMPLATE} --capabilities CAPABILITY_NAMED_IAM
fi
echo "Update requested for stack ${STACKNAME} with ${TEMPLATE}."
