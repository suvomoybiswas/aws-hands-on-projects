#!/bin/bash
# Validate a CloudFormation template
if [ $# -ne 1 ]; then
  echo "Usage: $0 <template-file>"
  exit 1
fi
aws cloudformation validate-template --template-body file://$1
