#!/bin/bash
# Usage: ./create-stack.sh <template-basename> <template-path> <KeyName-if-required>
# Examples:
#   ./create-stack.sh task1 templates/task1.yaml
#   ./create-stack.sh task3 templates/task3.yaml mykeypair
set -euo pipefail
if [ $# -lt 2 ]; then
  echo "Usage: $0 <stack-basename> <template-file> [KeyName]"
  exit 1
fi
STACKBASE="$1"
TEMPLATE="$2"
STACKNAME="Lab"
shift 2
EXTRA_PARAMS=()
if [ $# -ge 1 ]; then
  KEYNAME="$1"
  EXTRA_PARAMS+=(ParameterKey=KeyName,ParameterValue=${KEYNAME})
fi
aws cloudformation create-stack --stack-name ${STACKNAME} --template-body file://${TEMPLATE} --capabilities CAPABILITY_NAMED_IAM ${EXTRA_PARAMS[@]:+--parameters ${EXTRA_PARAMS[*]}}
echo "Create requested for stack ${STACKNAME} using template ${TEMPLATE}."
