#!/bin/bash
# Monitor stack resources (press Ctrl-C to stop)
watch -n 5 -d aws cloudformation describe-stack-resources --stack-name Lab --query 'StackResources[*].[LogicalResourceId,ResourceType,ResourceStatus]' --output table
