# Task 3 — Add an Amazon EC2 Instance to the Stack

This document explains adding an EC2 instance to the stack using `templates/task3.yaml`.

## Template highlights
- Adds a `KeyName` parameter for SSH access.
- Adds an `AmazonLinuxAMIID` parameter that fetches the AMI via SSM Parameter Store.
- Adds an `AppServer` EC2 instance resource that references the subnet and security group from earlier.

## Update the stack (console)
1. In the CloudFormation console, select stack `Lab` and click **Update**.
2. Choose **Replace current template** and upload `templates/task3.yaml`.
3. Provide the `KeyName` parameter (your EC2 key pair name).
4. Click **Update stack** and wait for `UPDATE_COMPLETE`.

## Update the stack (CLI)
```bash
./scripts/validate-template.sh templates/task3.yaml
./scripts/update-stack.sh templates/task3.yaml <YourKeyPairName>
./scripts/describe-stack.sh
```

## Notes
- The instance type is `t3.micro`. Modify if your account does not support t3 family.
- The `AmazonLinuxAMIID` parameter uses SSM so the template is region agnostic.
