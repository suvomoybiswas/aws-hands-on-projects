# Task 2 — Add an Amazon S3 Bucket to the Stack

This document explains how to modify `templates/task1.yaml` to add an S3 bucket and then update the running stack.

## How the template changes
- The new template (provided as `templates/task2.yaml`) contains the same resources as task1, plus a new `AWS::S3::Bucket` resource named `LabBucket`.

## Update the stack (console)
1. In the CloudFormation console, select stack `Lab` and click **Update**.
2. Choose **Replace current template** and upload `templates/task2.yaml`.
3. Click **Next** through the options until you reach the update confirmation. Review the **Change set** or preview to confirm an **Add** action for the S3 bucket.
4. Click **Update stack** and wait for `UPDATE_COMPLETE`.

## Update the stack (CLI)
```bash
./scripts/validate-template.sh templates/task2.yaml
./scripts/update-stack.sh templates/task2.yaml
./scripts/describe-stack.sh
```

## Notes
- The S3 bucket will be assigned a generated name unless you add `BucketName` explicitly.
