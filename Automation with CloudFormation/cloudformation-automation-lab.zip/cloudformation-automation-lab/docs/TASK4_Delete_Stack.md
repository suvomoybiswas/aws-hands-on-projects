# Task 4 — Delete the Stack

This document explains how to delete the stack and verify resource deletion.

## Delete (console)
1. In the CloudFormation console, select stack `Lab` and click **Delete**.
2. Confirm deletion. The stack will transition to `DELETE_IN_PROGRESS` and disappear when done.

## Delete (CLI)
```bash
./scripts/delete-stack.sh
```

## Verify deletion
- Check the VPC, EC2, and S3 consoles to confirm resources were removed.
- If the S3 bucket has objects, deletion may fail. Empty or remove objects before retrying, or use a retain-resources approach if you want to keep the bucket.
