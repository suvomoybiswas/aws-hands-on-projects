# Task 1 — Deploy a CloudFormation Stack

This document explains how to use `templates/task1.yaml` to deploy a stack named `Lab` that creates a VPC, subnet, and a security group.

## Steps (console)
1. Open the CloudFormation console and click **Create stack** > **With new resources (standard)**.
2. Upload `templates/task1.yaml` and click **Next**.
3. Enter **Stack name:** `Lab` and leave the default parameter values.
4. Click through and acknowledge any capabilities if required, then click **Create stack**.
5. Monitor the **Events** and **Resources** tabs until the stack reaches `CREATE_COMPLETE`.

## Steps (CLI)
```bash
./scripts/validate-template.sh templates/task1.yaml
./scripts/create-stack.sh task1 templates/task1.yaml
./scripts/describe-stack.sh
```

## Notes
- Do not change the Region during the lab.
- If you see errors, check the Events tab for details.
