# 🏗️ AWS VPC Configuration Lab Project

This project demonstrates how to **build and configure a Virtual Private Cloud (VPC)** on AWS with both **public and private subnets**, routing, a **NAT gateway**, and a **bastion host** for secure access.  

It replicates a common real-world AWS networking setup used in production environments for securely deploying resources.

---

## 📸 Screenshots

| Step | Description | Screenshot |
|------|--------------|-------------|
| 1 | Creating a VPC | ![Creating a VPC](./screenshots/1-creating-vpc.png) |
| 2 | Creating a Public Subnet | ![Creating a Public Subnet](./screenshots/2-creating-public-subnet.png) |
| 3 | Creating a Private Subnet | ![Creating a Private Subnet](./screenshots/3-creating-private-subnet.png) |
| 4 | Creating an Internet Gateway | ![Creating an Internet Gateway](./screenshots/4-creating-internet-gateway.png) |
| 5 | Configuring Route Tables | ![Configuring Route Tables](./screenshots/5-configuring-route-tables.png) |
| 6 | Launching a Bastion Server in the Public Subnet | ![Launching a Bastion Server](./screenshots/6-launching-bastion-server.png) |
| 7 | Creating a NAT Gateway | ![Creating a NAT Gateway](./screenshots/7-creating-nat-gateway.png) |
| 8 | Launching an Instance in the Private Subnet | ![Launching a Private Instance](./screenshots/8-launching-private-instance.png) |

---

## 🧠 Objectives

By the end of this project, you will have:

- Created a **VPC** with both **public** and **private** subnets.  
- Attached and configured an **Internet Gateway (IGW)** and a **NAT Gateway**.  
- Created **route tables** to route traffic between subnets and the internet.  
- Launched:
  - A **Bastion Host** in the public subnet.
  - A **Private EC2 Instance** accessible only through the bastion host.

---

## 🧩 Architecture Diagram

![VPC Architecture](./architecture/vpc-architecture-diagram.png)

**Architecture Components:**

- **VPC CIDR:** 10.0.0.0/16  
- **Public Subnet:** 10.0.0.0/24  
- **Private Subnet:** 10.0.2.0/23  
- **Internet Gateway (IGW):** Provides outbound connectivity for public subnet.  
- **NAT Gateway:** Enables outbound internet access from private subnet.  
- **Route Tables:**
  - **Public Route Table:** Routes 0.0.0.0/0 → IGW  
  - **Private Route Table:** Routes 0.0.0.0/0 → NAT Gateway  
- **Bastion Host:** Secure entry point to access private resources.  
- **Private Instance:** Resides in private subnet; accessed via bastion host.

---

## ⚙️ Step-by-Step Summary

### **1️⃣ Create a VPC**
- **CIDR:** 10.0.0.0/16  
- **DNS Hostnames:** Enabled  

### **2️⃣ Create Subnets**
- **Public Subnet:** 10.0.0.0/24  
  - Auto-assign public IPs: Enabled  
- **Private Subnet:** 10.0.2.0/23  

### **3️⃣ Create and Attach an Internet Gateway**
- Create `Lab IGW`
- Attach it to `Lab VPC`

### **4️⃣ Configure Route Tables**
- **Public Route Table:** Route `0.0.0.0/0 → IGW`
- **Private Route Table:** Default local route only

### **5️⃣ Launch Bastion Server**
- **Subnet:** Public Subnet  
- **AMI:** Amazon Linux 2023  
- **Type:** t3.micro  
- **Security Group:** Allow SSH from anywhere  

### **6️⃣ Create a NAT Gateway**
- Deploy in **Public Subnet**
- Allocate **Elastic IP**
- Update **Private Route Table** → `0.0.0.0/0 → NAT Gateway`

### **7️⃣ Launch Private Instance**
- **Subnet:** Private Subnet  
- **Security Group:** Allow SSH from VPC CIDR (10.0.0.0/16)  
- **Test Connection:** Use Bastion Host to SSH into it  

---

## 🧪 Optional: Connectivity Test

```bash
# Connect to Bastion first
ssh ec2-user@<bastion-public-ip>

# From Bastion, connect to private instance
ssh ec2-user@<private-instance-ip>
```

---

## 🧰 Tools & Services Used

- **Amazon VPC**
- **Amazon EC2**
- **Elastic IP**
- **Internet Gateway (IGW)**
- **NAT Gateway**
- **Route Tables & Subnet Associations**
- **Security Groups**

---

## 🏁 Key Learnings

- Designing and implementing secure **network architecture** in AWS.  
- Managing **private and public subnets** with correct routing.  
- Understanding **NAT vs Internet Gateways**.  
- Implementing **bastion host** access for private instances.  
- Strengthening cloud security and connectivity concepts.

---

## 🧑‍💻 Author

**Suvo Biswas**  
📍 Jamaica, New York  
💼 Cloud Computing | AWS | DevOps | Linux  
🔗 [GitHub Profile](https://github.com/yourusername)  
🔗 [LinkedIn Profile](https://linkedin.com/in/yourlinkedin)

---

## 🌟 How to Use

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/aws-vpc-lab.git
   ```
2. Open `README.md` to follow the documented lab steps.
3. Review the screenshots for visual confirmation.
