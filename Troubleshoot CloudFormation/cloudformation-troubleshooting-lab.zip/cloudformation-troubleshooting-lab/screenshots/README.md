# Screenshots folder

This folder contains placeholder files for screenshots. Replace these placeholder images with actual screenshots from your lab when you prepare the repo on GitHub.

Suggested placeholder file names:
- step1-jmespath.png
- step2-create-failed.png
- step2-cloud-init.png
- step3-drift.png
- step4-delete-failed.png
