#!/bin/bash
# Troubleshooting helper commands
echo "1) Show CREATE_FAILED events:"
aws cloudformation describe-stack-events --stack-name myStack --query "StackEvents[?ResourceStatus == 'CREATE_FAILED']"
echo
echo "2) Show stack status:"
aws cloudformation describe-stacks --stack-name myStack --output table
echo
echo "3) If instance exists, show latest cloud-init log (must SSH to instance to view actual logs)."
echo "4) To list EC2 instances named 'Web Server':"
aws ec2 describe-instances --filters "Name=tag:Name,Values='Web Server'" --query 'Reservations[].Instances[].[State.Name,PublicIpAddress]'
