#!/bin/bash
# Usage: ./create-stack.sh <KeyName>
set -euo pipefail
if [ -z "${1:-}" ]; then
  echo "Usage: $0 <KeyName>"
  exit 1
fi
KEYNAME="$1"
aws cloudformation create-stack \
  --stack-name myStack \
  --template-body file://template1.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --on-failure DO_NOTHING \
  --parameters ParameterKey=KeyName,ParameterValue=${KEYNAME}
echo "Stack create requested for myStack with key ${KEYNAME}."
