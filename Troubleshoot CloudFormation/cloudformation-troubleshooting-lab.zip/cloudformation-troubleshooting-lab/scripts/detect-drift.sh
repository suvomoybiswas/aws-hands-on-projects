#!/bin/bash
# Detect drift on the stack
set -euo pipefail
DRIFT_ID=$(aws cloudformation detect-stack-drift --stack-name myStack --output text --query 'StackDriftDetectionId')
echo "Drift detection started: ${DRIFT_ID}"
# Poll status until complete
while true; do
  status=$(aws cloudformation describe-stack-drift-detection-status --stack-drift-detection-id ${DRIFT_ID} --query 'DetectionStatus' --output text)
  echo "Status: ${status}"
  if [ "${status}" == "DETECTION_COMPLETE" ] || [ "${status}" == "DETECTION_FAILED" ]; then break; fi
  sleep 5
done
aws cloudformation describe-stack-resource-drifts --stack-name myStack --output table
