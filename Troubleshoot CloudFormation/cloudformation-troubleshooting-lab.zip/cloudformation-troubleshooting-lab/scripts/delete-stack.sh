#!/bin/bash
# Delete stack but retain the S3 bucket resource created by the stack.
# Usage: ./delete-stack.sh
set -euo pipefail
# Get logical resource id for the S3 bucket
LOGICAL_ID=$(aws cloudformation describe-stack-resources --stack-name myStack --query "StackResources[?ResourceType=='AWS::S3::Bucket'].LogicalResourceId" --output text)
echo "Retaining logical resource id: ${LOGICAL_ID}"
if [ -z "${LOGICAL_ID}" ]; then
  echo "Could not determine S3 logical id. Exiting."
  exit 1
fi
aws cloudformation delete-stack --stack-name myStack --retain-resources "${LOGICAL_ID}"
echo "Delete requested for stack myStack (S3 bucket retained)."
