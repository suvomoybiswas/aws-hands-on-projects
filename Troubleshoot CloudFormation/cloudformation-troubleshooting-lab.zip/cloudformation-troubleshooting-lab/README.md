# CloudFormation Troubleshooting Lab (GitHub Project)

This repository contains a polished, GitHub-ready version of an AWS CloudFormation troubleshooting lab. It documents the full exercise, provides a corrected CloudFormation template, and includes scripts you can use to reproduce the steps in a real AWS account (for educational use).

## Repository structure

```
cloudformation-troubleshooting-lab/
├── README.md
├── template1.yaml
├── screenshots/
│   └── README.md
├── scripts/
│   ├── create-stack.sh
│   ├── describe-stack.sh
│   ├── troubleshoot-stack.sh
│   ├── delete-stack.sh
│   └── detect-drift.sh
└── docs/
    ├── TASK1_JMESPATH.md
    ├── TASK2_Troubleshoot_Stack.md
    ├── TASK3_Detect_Drift.md
    └── TASK4_Delete_Stack.md
```

## Quick summary

- **Objective:** Learn to create an AWS CloudFormation stack, diagnose a Create failure caused by broken userdata, fix the template, detect drift after manual changes, and delete the stack while retaining an S3 bucket that contains objects.
- **Key topics:** JMESPath, AWS CLI, CloudFormation `--on-failure` behavior, inspecting EC2 userdata logs, drift detection, and `delete-stack` with `--retain-resources`.
- **Important:** This repository includes a working `template1.yaml` (with the corrected `httpd` install). Use in your own AWS account responsibly and ensure you have proper permissions and cost controls enabled.

## How to use this repo

1. Review `docs/` for step-by-step details and background.
2. Inspect `template1.yaml` (the CloudFormation template used in the lab).
3. Use the scripts in `scripts/` as convenience wrappers for the AWS CLI commands used in the lab. Modify variables (like `KeyName`) before running.
4. Replace the placeholder images in `screenshots/` with your own screenshots if desired.
5. Zip file included in this repository: `cloudformation-troubleshooting-lab.zip` (provided alongside this project).

## License & disclaimers

This is an educational lab. Use at your own risk. Make sure you understand the costs of launching EC2 instances, S3 buckets, etc. Clean up resources when finished. This repo is not affiliated with AWS.

---
