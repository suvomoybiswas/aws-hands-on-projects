# Task 3 — Detect Drift

This document explains the drift detection step.

## Scenario
- After creating the stack successfully, manually modify the security group's inbound SSH rule to restrict SSH to only your IP via the EC2 console. This creates drift for the Security Group resource because it no longer matches the template definition (which allowed 0.0.0.0/0).

## Commands
- Detect drift: `aws cloudformation detect-stack-drift --stack-name myStack`
- Check detection status: `aws cloudformation describe-stack-drift-detection-status --stack-drift-detection-id <id>`
- Describe resource drifts: `aws cloudformation describe-stack-resource-drifts --stack-name myStack`
- Simpler summary: `aws cloudformation describe-stack-resources --stack-name myStack --query 'StackResources[*].[ResourceType,ResourceStatus,DriftInformation.StackResourceDriftStatus]' --output table`

Note: Adding objects to an S3 bucket does **not** cause drift; changes to bucket properties do.
