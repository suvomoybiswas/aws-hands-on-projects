# Task 2 — Troubleshoot CloudFormation Stack Creation

This document captures the troubleshooting steps and rationale for Task 2 used in the lab.

## Problem summary
- Initial stack creation failed because the userdata attempted to `yum install -y http` (invalid package name).
- The stack used a WaitCondition that expected a success signal from the instance; the userdata failed and thus the WaitCondition timed out, causing stack failure/rollback.

## Key steps to reproduce
1. Create stack:
   `aws cloudformation create-stack --stack-name myStack --template-body file://template1.yaml --capabilities CAPABILITY_NAMED_IAM --on-failure DO_NOTHING --parameters ParameterKey=KeyName,ParameterValue=vockey`
2. Monitor events:
   `aws cloudformation describe-stack-events --stack-name myStack --query "StackEvents[?ResourceStatus == 'CREATE_FAILED']"`
3. SSH to the instance (if `--on-failure DO_NOTHING` was used) and inspect `/var/log/cloud-init-output.log` for `No package http available` and `Failed running /var/lib/cloud/instance/scripts/part-001`.
4. Fix template (`yum install -y httpd`), delete failed stack, and recreate.

## Fix applied
- Change `yum install -y http` to `yum install -y httpd` in the `UserData` section of `template1.yaml`.
- Re-run create-stack; the instance should properly install and start httpd and signal the wait handle.
