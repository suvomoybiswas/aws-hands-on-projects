# Task 4 — Delete Stack but Retain S3 Bucket (Challenge)

## Problem summary
- `aws cloudformation delete-stack --stack-name myStack` failed with `DELETE_FAILED` because the S3 bucket created by the stack contained objects. CloudFormation will not delete an S3 bucket that still contains objects.

## Challenge requirement
- Keep the S3 bucket and its objects but still delete the CloudFormation stack and reach `DELETE_COMPLETE` status.

## Solution
1. Determine the CloudFormation logical resource id of the bucket:
   `aws cloudformation describe-stack-resources --stack-name myStack --query "StackResources[?ResourceType=='AWS::S3::Bucket'].LogicalResourceId" --output text`
2. Use `--retain-resources` with the logical resource id when deleting the stack:
   `aws cloudformation delete-stack --stack-name myStack --retain-resources <LogicalResourceId>`

This will delete the stack object and all deletable resources, but leave the S3 bucket (and its objects) intact.

## Notes & alternatives
- If you must automate keeping the bucket but transferring ownership of the data, consider copying objects to another bucket or enabling lifecycle rules before deletion.
- You may also empty the bucket (aws s3 rm s3://bucket --recursive) and then delete the stack without retain-resources.
