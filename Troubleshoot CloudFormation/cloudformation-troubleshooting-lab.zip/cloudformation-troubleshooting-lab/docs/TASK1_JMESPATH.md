# Task 1 — JMESPath Practice

This file documents the JMESPath usage examples from the lab.

Examples (use these in the AWS CLI `--query` parameter or on jmespath.org):

- Return all desserts:
  `desserts`

- Return second dessert:
  `desserts[1]`

- Return the name of the first dessert:
  `desserts[0].name`

- Return names of all desserts:
  `desserts[].name`

- Filter to the Carrot cake object:
  `desserts[?name=='Carrot cake']`

- Query CloudFormation stack resources to get the LogicalResourceId of the EC2 instance:
  `StackResources[?ResourceType == 'AWS::EC2::Instance'].LogicalResourceId`

Tip: Use these expressions with `aws cloudformation describe-stack-resources --stack-name myStack --query '<expression>' --output text`
